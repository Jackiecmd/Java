package work3.work3;

public interface Playable {
    void play();
}
