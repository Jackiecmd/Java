package work3.work3;

public class AudioPlayer implements Playable {
    @Override
    public void play() {
        System.out.println("Playing audio...");
    }
}
