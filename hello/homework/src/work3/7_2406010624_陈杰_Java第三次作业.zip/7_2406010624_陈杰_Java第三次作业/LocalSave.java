package work3.work7;

public class LocalSave extends GameSave{
    @Override
    public void loadSave() {
        System.out.println("Loading save from local storage...");
    }
}
