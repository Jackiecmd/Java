package work3.work7;

public class CloudSave extends GameSave{
    @Override
    public void loadSave() {
        System.out.println("Loading save from cloud... 剩余时间5秒");
    }
}
