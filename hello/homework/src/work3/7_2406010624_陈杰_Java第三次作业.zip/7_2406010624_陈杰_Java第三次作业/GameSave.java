package work3.work7;

abstract class GameSave {
    public abstract void loadSave();
}
