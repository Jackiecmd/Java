package work3.work5;

public interface Sensor {
    void readData();
}
