package work3.work8;

public class SmartDevice {
    public void activateEcoMode(){
        System.out.println("General energy saving activated");
    }
}
