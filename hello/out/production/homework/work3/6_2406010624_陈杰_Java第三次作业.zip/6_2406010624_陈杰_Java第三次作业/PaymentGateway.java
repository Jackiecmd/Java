package work3.work6;

public abstract class PaymentGateway {
    public abstract void processPayment(double amount);
}
