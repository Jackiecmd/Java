package work3.work9;

public class Transaction {
    public boolean checkRisk(){
        return false;
    }
}
