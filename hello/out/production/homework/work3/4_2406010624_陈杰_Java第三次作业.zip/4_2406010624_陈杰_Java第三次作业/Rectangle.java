package work3.work4;

public class Rectangle implements Shape{
    @Override
    public void render() {
        System.out.println("Rendering Rectangle");
    }
}
