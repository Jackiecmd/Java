package work3.work4;

public interface Shape {
    void render();
}
